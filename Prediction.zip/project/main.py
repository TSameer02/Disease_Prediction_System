import os
import pickle
import streamlit as st
from streamlit_option_menu import option_menu

# set page configuration...
st.set_page_config(page_title="Health Guard",layout='wide')

# setting the working directory of the main.py
working_dir=os.path.dirname(os.path.abspath(__file__))

# loading the saved models
diabetes_model=pickle.load(open(f'{working_dir}/diabetes_model.sav','rb'))
heart_model=pickle.load(open(f'{working_dir}/heart_model.sav','rb'))
parkinsons_model=pickle.load(open(f'{working_dir}/parkinsons_model.sav','rb'))

# sidebar for navigation 
with st.sidebar:
    selected=option_menu("Multiple Disease Prediction System",['Diabetes Prediction','Heart Disease Prediction','Parkinsons Prediction'],menu_icon='hospital-fill',icons=['activity','heart','person'],default_index=0)

# diabetes Prediction Page
if selected == 'Diabetes Prediction':
    # Page Titel
    st.title("Diabetes Prediction Using ML")
    # setting up the number of colums with the name col1,col2,col3
    col1,col2,col3=st.columns(3)
    with col1:
        Pregnancies=st.text_input("Number of Pregnencies")
    with col2:
        glucose=st.text_input("Glucose Level")
    with col3:
        Bloodpressure=st.text_input("Blood Pressure Value.")

    with col1:
        Skinthickness=st.text_input("Skin Thickness Value.")
    with col2:
        Insulin=st.text_input("Insulin Level")
    with col3:
        Bmi=st.text_input("BMI Value")

    with col1:
        Diabetespedigreefunction=st.text_input("Diabetes Pedigree Function.")
    with col2:
        Age=st.text_input("Age of the person")
    
    # code for prediction 
    diab_diagonosis=""

    #creation of the button
    if st.button('Diabetes Test Result'):
        user_input=[Pregnancies,glucose,Bloodpressure,Skinthickness,Insulin,Bmi,Diabetespedigreefunction,Age]
        user_input=[float(x) for x in user_input]
        diab_prediction=diabetes_model.predict([user_input])

        if diab_prediction[0]==1:
            diab_diagonosis="The person is Diabetic"
        else:
            diab_diagonosis="The person is not Diabetic"

    st.success(diab_diagonosis)

# --------------------------------------------------------------------------------------

# heart disease prediction page.
if selected == 'Heart Disease Prediction':
    # Page Titel
    st.title("Heart Disease Prediction Using ML")
    # setting up the number of colums with the name col1,col2,col3
    col1,col2,col3=st.columns(3)
    with col1:
        ag=st.text_input("Age")
    with col2:
        sex=st.text_input("Gender:0-Female,1-Male")
    with col3:
        chestpain=st.text_input("Chest Pain Types.")

    with col1:
        resting=st.text_input("Resting Blood Pressure.")
    with col2:
        serum=st.text_input("Serum Cholestoral in mg/dl")
    with col3:
        bloodsugar=st.text_input("Fasting Blood Sugar>120 mg/dl.")

    with col1:
        electrocardio=st.text_input("Resting Electrocardiographic Result.")    
    with col2:
        heartrate=st.text_input("Maximum Heart Rate Achieved.")
    with col3:
        exercise=st.text_input("Execise Induced Angina.")

    with col1:
        stdepression=st.text_input("ST depression include by exercise.")    
    with col2:
        slope=st.text_input("Slope of the peak exercise ST segment.")
    with col3:
        major=st.text_input("Major Vessels colored by flourosopy.")

    with col1:
        defect=st.text_input("thal:0=normal;1=fixed defect:2=reversable defect(Thelasiniea).")  
    
    # code fro prediction
    heart_test=""

    if st.button('Heart Disease Test Result'):
        user_input_heart=[ag,sex,chestpain,resting,serum,bloodsugar,electrocardio,heartrate,exercise,stdepression,slope,major,defect]
        user_input_heart=[float(i) for i in user_input_heart]
        heart_prediction=heart_model.predict([user_input_heart])
        if heart_prediction[0]==1:
            heart_test="The person has heart disease."
        else:
            heart_test="The person has not heart disease."
            
    st.success(heart_test)

# -----------------------------------------------------------------------------------

# parkinsons prediction page..
if selected=='Parkinsons Prediction':
    st.title("Parkinsons Prediction Using ML")
    # setting up the number of colums with the name
    col1,col2,col3,col4,col5=st.columns(5)
    with col1:
        mdvp1=st.text_input("MDVP:Fo(Hz)")
    with col2:
        mdvp2=st.text_input("MDVP:Fhi(Hz)")
    with col3:
        mdvp3=st.text_input("MDVP:Flo(Hz)")
    with col4:
        mdvp4=st.text_input("MDVP:Jitter(%)")
    with col5:
        mdvp5=st.text_input("MDVP:Jitter(Abs)")

    with col1:
        mdvp6=st.text_input("MDVP:RAP")
    with col2:
        mdvp7=st.text_input("MDVP:PPQ")
    with col3:
        jitter=st.text_input("Jitter:DDP")
    with col4:
        shimmer1=st.text_input("MDVP:Shimmer")
    with col5:
        shimmer2=st.text_input("MDVP:Shimmer(db)")

    with col1:
        shimmer3=st.text_input("Shimmer:APQ3")
    with col2:
        shimmer4=st.text_input("Shimmer:APQ5")
    with col3:
        mdvp8=st.text_input("MDVP:APQ")
    with col4:
        shimmer5=st.text_input("Shimmer:DDA")
    with col5:
        nhr=st.text_input("NHR")

    with col1:
        hnr=st.text_input("HNR")
    with col2:
        rpde=st.text_input("RPDE")
    with col3:
        dfa=st.text_input("DFA")
    with col4:
        spread1=st.text_input("Spread1")
    with col5:
        spread2=st.text_input("spread2")
    
    with col1:
        d2=st.text_input("D2")
    with col2:
        ppe=st.text_input("PPE")

    # code prediction
    parkin_msg=""
    if st.button("Parkinsons Test Result"):
        user_input_parkinsons=[mdvp1,mdvp2,mdvp3,mdvp4,mdvp5,mdvp6,mdvp7,jitter,shimmer1,shimmer2,shimmer3,shimmer4,mdvp8,shimmer5,nhr,hnr,rpde,dfa,spread1,spread2,d2,ppe]
        user_input_parkinsons=[float(j) for j in user_input_parkinsons]
        parkinsons_predictions=parkinsons_model.predict([user_input_parkinsons])
        if parkinsons_predictions[0]==1:
            parkin_msg="The person has parkinsons diseases."
        else:
            parkin_msg="The persons has not parkinsons diseases."

    st.success(parkin_msg)

# ----------------------------------------------------------------------------------------------------------------
